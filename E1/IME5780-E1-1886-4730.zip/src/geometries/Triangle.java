package geometries;

import java.util.List;

import primitives.*;

public class Triangle extends Polygon {
	Plane _plane;
	Point3D p1;
	Point3D p2;
	Point3D p3;

	public Triangle(List<Point3D> _points, Plane plane, Plane _plane, Point3D p1, Point3D p2, Point3D p3) {
		super(_points, plane);
		this._plane = _plane;
		this.p1 = p1;
		this.p2 = p2;
		this.p3 = p3;
	}

	@Override
	public Vector getNormal(Point3D p) {
		return _plane.getNormal(p);
	}
}