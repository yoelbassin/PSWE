package geometries;

import primitives.*;

public interface Geometry {
	abstract Vector getNormal(Point3D p);
}
