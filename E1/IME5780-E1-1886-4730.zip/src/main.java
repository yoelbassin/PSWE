
/**
 * Yoel Bassin
 * 212431886 
 * Asaf Hillel 
 * 323824730
 * bassin.yoel@gmail.com
 * asafdavi@g.jct.ac.il
 */

import primitives.*;

public class main {
	public static void main(String args[]) {
		VectorTest();
	}

	public static void VectorTest() {
		/**
		 * Constructor for vector 0
		 */
		Vector ZeroVector = new Vector(Vector.ZeroVec);
		Coordinate x = new Coordinate(1);
		Coordinate y = new Coordinate(2);
		Coordinate z = new Coordinate(3);
		Point3D testP1 = new Point3D(x, y, z);
		Vector vec1 = new Vector(testP1);
		Vector vec2 = new Vector(testP1);
		Vector vec3 = new Vector(testP1);
		/**
		 * Add to vector 0
		 */
		vec1 = (vec1.Add(vec1.scale(-1))); 
		/**
		 * subtract to vector 0
		 */
		vec2 = (vec2.Sub(vec2));
		/**
		 * dot product of vector 0
		 */
		double dot = vec3.dotProduct(ZeroVector);
		/**
		 * cross product of vector 0
		 */
		vec3 = (vec3.crossProduct(ZeroVector));
		System.out.println(dot);
		/**
		 * orthogonal vectors dot product
		 */
		Coordinate a = new Coordinate(2);
		Coordinate b = new Coordinate(1);
		Coordinate c = new Coordinate(-1);
		Coordinate d = new Coordinate(1);
		Coordinate e = new Coordinate(-2);
		Coordinate f = new Coordinate(0);
		Point3D testP2 = new Point3D(a, b, c);
		Point3D testP3 = new Point3D(d, e, f);
		vec1 = new Vector(testP2);
		vec2 = new Vector(testP3);
		double dotproduct = vec1.dotProduct(vec2);
		System.out.println(dotproduct);
	}

}
