package primitives;

import java.lang.Math;

public class Vector {

	Point3D vec;

	public static Point3D ZeroVec = new Point3D(Coordinate.ZERO, Coordinate.ZERO, Coordinate.ZERO);

	public Vector(Point3D vec) {
		try {
			if (vec.equals(ZeroVec))
				throw new NullPointerException("Vector 0");
			this.vec = vec;
		} catch (NullPointerException a) {
			System.out.println("Error: " + a);
		}
	}

	public Point3D getVec() {
		return vec;
	}

	@Override
	public boolean equals(Object other) {
		if (vec.equals(other) == true) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		try {
			if (vec.equals(ZeroVec))
				throw new NullPointerException("vector 0");
			return "Vector [vec=" + vec.toString() + "]";
		} catch (NullPointerException a) {
			System.out.println("Error: " + a);
			return "Vector Zero (0,0,0)";
		}
	}

	/**
	 * add function
	 * 
	 * @param other
	 * @return
	 */
	public Vector Add(Vector other) {
		Point3D temp;
		Vector OtherVec;
		temp = new Point3D(this.vec.getX().add(other.getVec().getX()), this.vec.getY().add(other.getVec().getY()),
				this.vec.getZ().add(other.getVec().getZ()));
		OtherVec = new Vector(temp);
		return OtherVec;
	}

	/**
	 * subtract function
	 * 
	 * @param other
	 * @return
	 */
	public Vector Sub(Vector other) {
		Point3D temp;
		Vector OtherVec;
		temp = new Point3D(this.vec.getX().subtract(other.getVec().getX()),
				this.vec.getY().subtract(other.getVec().getY()), this.vec.getZ().subtract(other.getVec().getZ()));
		OtherVec = new Vector(temp);
		return OtherVec;
	}

	/**
	 * dot product multiplication
	 * 
	 * @param other
	 * @return
	 */
	public double dotProduct(Vector other) {
		try {
			if (other.equals(ZeroVec))
				throw new NullPointerException("vector 0 mulipication");
			double temp;
			temp = (this.vec.getX().multiply(other.getVec().getX()).get()
					+ this.vec.getY().multiply(other.getVec().getY()).get()
					+ this.vec.getZ().multiply(other.getVec().getZ()).get());
			if (temp == 0)
				throw new NullPointerException("vector 0");
			return temp;
		} catch (NullPointerException a) {
			System.out.println("Error: " + a);
			return 0;
		}
	}

	/**
	 * cross product multiplication
	 * 
	 * @param other
	 * @return
	 */
	public Vector crossProduct(Vector other) {
		try {
			if (other.equals(ZeroVec))
				throw new NullPointerException("vector 0 mulipication");
			Point3D temp;
			Vector OtherVec;
			Coordinate x;
			Coordinate y;
			Coordinate z;
			x = this.vec.getY().multiply(other.getVec().getZ())
					.subtract(this.getVec().getZ().multiply(other.getVec().getY()));
			y = this.vec.getZ().multiply(other.getVec().getX())
					.subtract(this.getVec().getX().multiply(other.getVec().getZ()));
			z = this.vec.getX().multiply(other.getVec().getY())
					.subtract(this.getVec().getY().multiply(other.getVec().getX()));
			temp = new Point3D(x, y, z);
			OtherVec = new Vector(temp);
			return OtherVec;
		} catch (NullPointerException a) {
			System.out.println("Error: " + a);
			return this;
		}
	}

	/**
	 * squared length of the vector
	 * 
	 * @return
	 */
	public double lengthSQ() {
		double length = Math.pow(this.vec.getX().get(), 2) + Math.pow(this.vec.getY().get(), 2)
				+ Math.pow(this.vec.getZ().get(), 2);
		return length;
	}

	/**
	 * length of the vector
	 * 
	 * @return
	 */
	public double length() {
		return Math.sqrt(lengthSQ());
	}

	/**
	 * change size of the vector
	 * 
	 * @param num
	 * @return
	 */
	public Vector scale(double num) {
		Point3D temp;
		Vector OtherVec;
		temp = new Point3D(this.vec.getX().scale(num), this.vec.getY().scale(num), this.vec.getZ().scale(num));
		OtherVec = new Vector(temp);
		return OtherVec;
	}

	/**
	 * normalize vector to new vector
	 */
	public void newNormal() {
		double temp;
		Vector OtherVec;
		temp = 1 / this.length();
		OtherVec = this.scale(temp);
		this.vec = OtherVec.vec;
	}

	/**
	 * normalize vector
	 * 
	 * @return
	 */
	public Vector Normal() {
		Vector OtherVec = new Vector(this.vec);
		OtherVec.newNormal();
		return OtherVec;
	}

}
