package primitives;

import java.lang.Math;

public class Point3D {
	private Coordinate x;
	private Coordinate y;
	private Coordinate z;

	public Point3D(Coordinate x, Coordinate y, Coordinate z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	@Override
	public String toString() {
		return "Point3D [x=" + x.toString() + ", y=" + y.toString() + ", z=" + z.toString() + "]";
	}

	public Coordinate getX() {
		return x;
	}

	public Coordinate getY() {
		return y;
	}

	public Coordinate getZ() {
		return z;
	}

	/**
	 * equal function
	 */
	public boolean equals(Point3D other) {
		if (x.equals(other.getX()) == true) {
			if (y.equals(other.getY()) == true) {
				if (z.equals(other.getZ()) == true)
					return true;
			}
		}
		return false;
	}

	/**
	 * Subtract function
	 * 
	 * @param other
	 * @return
	 */
	public Vector subtract(Point3D other) {
		Point3D temp;
		Vector vec;
		temp = new Point3D(other.getX().subtract(this.getX()), other.getY().subtract(this.getY()),
				other.getZ().subtract(this.getZ()));
		vec = new Vector(temp);
		return vec;
	}

	/**
	 * add function
	 * 
	 * @param other
	 * @return
	 */
	public Point3D addVec(Vector other) {
		Point3D temp;
		temp = new Point3D(this.getX().add(other.getVec().getX()), this.getY().add(other.getVec().getY()),
				this.getZ().add(other.getVec().getZ()));
		return temp;
	}

	public Point3D addV(Point3D other) {
		Point3D temp;
		temp = new Point3D(this.getX().add(other.getX()), this.getY().add(other.getY()), this.getZ().add(other.getZ()));
		return temp;
	}
	/**
	 * Squared distance
	 * 
	 * @param other
	 * @return
	 */
	public double distanceSQ(Point3D other) {
		if (this.equals(other))
			return 0;
		double temp = Math.pow(this.getX().subtract(other.getX()).get(), 2)
				+ Math.pow(this.getY().subtract(other.getY()).get(), 2)
				+ Math.pow(this.getY().subtract(other.getY()).get(), 2);
		return temp;
	}

	/**
	 * distance
	 * 
	 * @param other
	 * @return
	 */
	public double distance(Point3D other) {
		return Math.sqrt(distanceSQ(other));
	}

}
