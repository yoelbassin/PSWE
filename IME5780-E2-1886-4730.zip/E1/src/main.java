
/*
 * Yoel Bassin
 * 212431886 
 * Asaf Hillel 
 * 323824730
 * bassin.yoel@gmail.com
 * asafdavi@g.jct.ac.il
 */

import primitives.*;
import geometries.*;

public class main {
	public static void main(String args[]) {

	}

}
